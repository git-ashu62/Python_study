from numbers.factors import getFactors 


print(getFactors(100))